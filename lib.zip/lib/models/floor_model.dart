class FloorModel {
  double width;
  double length;

  FloorModel({
    this.width = 0.0,
    this.length = 0.0,
  });
}
